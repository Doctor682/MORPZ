import React from 'react';
import { StyleSheet, Text, View, Image, ImageBackground } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider } from 'react-redux';  // Імпортуємо Provider
import store from './redux/store';  // Імпортуємо store, який ми налаштували

import Main_Buttons from './components/Main_Buttons';
import RegisterScreen from './screens/RegisterScreen';
import LoginScreen from './screens/LoginScreen';
import AccountPage from './screens/AccountPage';
import Forum from './screens/Forum';
import AppBackground from './components/AppBackground';

const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider store={store}>  {/* Обгортаємо додаток в Provider */}
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Register" component={RegisterScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="AccountPage" component={AccountPage} />
          <Stack.Screen name="Forum" component={Forum} />
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}

function HomeScreen({ navigation }) {
  return (
    <AppBackground>
      <Image
        source={require('./assets/photo/23b0375309d4049e6a673a0f5c116f10-removebg-preview.png')}
        style={styles.logo}
      />
      <Text style={styles.header}>Форум власників екзотичних тварин</Text>
      <Main_Buttons navigation={navigation} />
    </AppBackground>
  );
}

const styles = StyleSheet.create({
  logo: {
    width: 200,
    height: 200,
    marginBottom: 30,
    backgroundColor: "none",
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 40,
    color: '#333',
  },
  bodyText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 10,
    color: '#333',
  },
});
