import { createSlice } from '@reduxjs/toolkit';

// Початковий стан
const initialState = {
  email: '',      // електронна пошта користувача
  photo: null,    // фото користувача
  posts: []       // пости користувача
};

export const userSlice = createSlice({
  name: 'user',
  initialState: {
    email: '',
    photo: null,
    posts: [],  // Масив для збереження постів
  },
  reducers: {
    setUser: (state, action) => {
      state.email = action.payload.email;
    },
    clearUser: (state) => {
      state.email = '';
      state.photo = null;
      state.posts = [];
    },
    setPhoto: (state, action) => {
      state.photo = action.payload;
    },
    addPost: (state, action) => {
      state.posts.push(action.payload);
    },
  },
});

export const { setUser, clearUser, setPhoto, addPost } = userSlice.actions;
export default userSlice.reducer;

