import { Client, Account, Storage } from 'appwrite';

const client = new Client();
client
  .setEndpoint('https://cloud.appwrite.io/v1') 
  .setProject('67b5c96e0021a7ee7881'); 

const account = new Account(client);
const storage = new Storage(client);

export { account, storage };
