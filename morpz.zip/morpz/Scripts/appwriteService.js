import { account } from '../Scripts/appwriteConfig';
import * as ImagePicker from 'expo-image-picker';

export const uploadPhoto = async () => {
  let result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [4, 3],
    quality: 1,
  });

  if (result.canceled) {
    return null;
  }

  const imageUri = result.assets[0].uri;
  const match = /\.(\w+)$/.exec(imageUri);
  const filename = `upload_${Date.now()}.${match ? match[1] : 'jpg'}`;
  const fileId = `file_${Date.now()}`;
  const type = match ? `image/${match[1]}` : 'image/jpeg';

  try {
    const userSession = await account.get();

    const formData = new FormData();
    formData.append('fileId', fileId);
    formData.append('file', {
      uri: imageUri,
      name: filename,
      type,
    });

    const response = await fetch(
      'https://cloud.appwrite.io/v1/storage/buckets/67d1729c001a404582d3/files',
      {
        method: 'POST',
        headers: {
          'X-Appwrite-Project': '67b5c96e0021a7ee7881',
          'X-Appwrite-Session': userSession.$id,
          'Content-Type': 'multipart/form-data',
        },
        body: formData,
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result?.message || 'Failed to upload image.');
    }

    return result.$id;
  } catch (error) {
    console.error('Upload error:', error);
    return null;
  }
};

export const getPhotoUrl = async (fileId) => {
  try {
    // Генеруємо публічний URL для фото
    const photoUrl = await storage.getFileView(
      '67d1729c001a404582d3',  // ID вашого бакету
      fileId,  // ID файлу, який потрібно отримати
    );

    return photoUrl.href;  // Повертаємо URL фото
  } catch (error) {
    console.log('Помилка отримання фото:', error.message);
    throw error;  // Кидаємо помилку, якщо не вдалося отримати URL
  }
};
