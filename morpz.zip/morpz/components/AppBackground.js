import React, { useState } from 'react';
import { View, Image, StyleSheet, ActivityIndicator } from 'react-native';

const AppBackground = ({ children }) => {
  const [loading, setLoading] = useState(true); // Стан завантаження зображення

  return (
    <View style={styles.container}>
      {/* Фонове зображення */}
      <Image
        source={require('../assets/photo/paw-prints-background-with-hearts-decoration_18591-84208.jpg')}
        style={styles.background}
        resizeMode="cover"
        onLoad={() => setLoading(false)} // Коли завантажиться - вимикаємо індикатор
      />
      
      {/* Показуємо індикатор завантаження, поки фото не підвантажилось */}
      {loading && (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color="#ff5722" />
        </View>
      )}

      {/* Напівпрозорий шар для затемнення */}
      <View style={styles.overlay} />

      {/* Вміст екрану */}
      <View style={styles.content}>{children}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  background: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.5)', // Напівпрозорість
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  loaderContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.7)', // Легке затемнення фону під час завантаження
  },
});

export default AppBackground;
