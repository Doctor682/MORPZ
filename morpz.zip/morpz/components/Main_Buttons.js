import React from 'react';
import { Button, View, StyleSheet } from 'react-native';

const handleRegister = (navigation) => {
  // Перехід на екран реєстрації
  navigation.navigate('Register');
};

const handleLogin = (navigation) => {
  // Перехід на екран логіну
  navigation.navigate('Login');
};

export default function Main_Buttons({ navigation }) {
  return (
    <View style={styles.button_container}>
      <Button title="Зареєструватися" onPress={() => handleRegister(navigation)} />
      <Button title="Увійти" onPress={() => handleLogin(navigation)} />
    </View>
  );
}

const styles = StyleSheet.create({
  button_container: {
    flex: 1,
    justifyContent: 'center', // Центруємо кнопки по вертикалі
  },
});