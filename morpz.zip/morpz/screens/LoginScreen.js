import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import { account } from '../Scripts/appwriteConfig';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Помилка', 'Будь ласка, заповніть всі поля');
      return;
    }

    try {
      await account.createEmailPasswordSession(email, password);
      Alert.alert('Успіх', 'Вхід виконано успішно', [
        { text: 'OK', onPress: () => navigation.navigate('AccountPage') },
      ]);
    } catch (error) {
      Alert.alert('Помилка', error.message || 'Невірний email або пароль');
    }
  };

  const handleExit = async () => {
    try {
      await account.deleteSession('current'); // Вихід з облікового запису
      Alert.alert('Вихід', 'Ви вийшли з акаунта');
    } catch (error) {
      Alert.alert('Помилка', 'Не вдалося вийти');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Вхід</Text>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        style={styles.input}
      />
      <TextInput
        placeholder="Пароль"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      <Button title="Увійти" onPress={handleLogin} />
      <Text
        style={styles.registerText}
        onPress={() => navigation.navigate('Register')}
      >
        Немає акаунта? Зареєструватися
      </Text>
      <View style={styles.exitButtonContainer}>
        <Button title="Вийти" onPress={handleExit} color="red" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  registerText: {
    marginTop: 15,
    textAlign: 'center',
    color: 'blue',
    textDecorationLine: 'underline',
  },
  exitButtonContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
});

export default LoginScreen;
