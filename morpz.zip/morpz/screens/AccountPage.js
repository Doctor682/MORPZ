import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { account } from '../Scripts/appwriteConfig';
import { uploadPhoto } from '../Scripts/appwriteService';
import { setUser, clearUser, setPhoto, addPost } from '../redux/userSlice';

const AccountPage = ({ navigation }) => {
  const dispatch = useDispatch();
  const userEmail = useSelector(state => state.user.email);
  const photo = useSelector(state => state.user.photo);
  const [postText, setPostText] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = await account.get();
        dispatch(setUser({ email: user.name }));
      } catch (error) {
        console.log('Помилка отримання даних користувача:', error.message);
        navigation.navigate('Login');
      }
    };

    fetchUserData();
  }, [dispatch, navigation]);

  const handleLogout = async () => {
    try {
      await account.deleteSession('current');
      dispatch(clearUser());
      navigation.navigate('Login');
    } catch (error) {
      console.log('Помилка виходу:', error.message);
    }
  };

const handlePhotoUpload = async () => {
  try {
    const photoUrl = await uploadPhoto();
    if (photoUrl) {
      dispatch(setPhoto(photoUrl)); // Зберігаємо URL в Redux
      alert(`Фото успішно завантажене!`);
    } else {
      alert('Не вдалося завантажити фото.');
    }
  } catch (error) {
    console.log('Помилка завантаження фото:', error.message);
    alert('Сталася помилка під час завантаження фото.');
  }
};

  const handlePost = () => {
    if (!postText) {
      alert('Введіть текст поста!');
      return;
    }
    dispatch(addPost({ text: postText, photo }));
    setPostText('');
    alert('Пост успішно створено!');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.email}>{userEmail}</Text>
      <Text style={styles.header}>Ласкаво просимо на сторінку акаунта!</Text>
      
      
      <TextInput
        style={styles.input}
        placeholder="Напишіть свій пост..."
        value={postText}
        onChangeText={setPostText}
      />
      
      <TouchableOpacity style={styles.button} onPress={handlePhotoUpload}>
        <Text style={styles.buttonText}>Завантажити фото</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={handlePost}>
        <Text style={styles.buttonText}>Опублікувати</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.forumButton]} onPress={() => navigation.navigate('Forum')}>
        <Text style={styles.buttonText}>Перейти до форуму</Text>
      </TouchableOpacity>

      
      <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleLogout}>
        <Text style={styles.buttonText}>Вийти</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  email: {
    position: 'absolute',
    top: 40,
    right: 20,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#555',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  photoText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 10,
  },
  input: {
    width: '80%',
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 12,
    borderRadius: 8,
    marginVertical: 10,
    width: '80%',
    alignItems: 'center',
  },
  logoutButton: {
    backgroundColor: '#FF3B30',
  },
  forumButton: {
    backgroundColor: '#28A745',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AccountPage;
