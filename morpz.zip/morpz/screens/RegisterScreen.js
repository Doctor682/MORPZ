import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import AppBackground from '../components/AppBackground';
import { account } from '../Scripts/appwriteConfig';

export default function RegisterScreen({navigation}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

   const handleRegister = async () => {
    if (!email || !password || !name) {
      Alert.alert('Помилка', 'Всі поля мають бути заповнені');
      return;
    }

    try {
      await account.create(
        'unique()', // Генеруємо унікальний ID користувача
        email,
        password,
        name
      );
      Alert.alert('Успіх', 'Реєстрація пройшла успішно', [
        { text: 'OK', onPress: () => navigation.navigate('login') },
      ]);
    } catch (error) {
      Alert.alert('Помилка', error.message || 'Щось пішло не так');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Реєстрація</Text>
      <TextInput
        placeholder="Ім'я"
        value={name}
        onChangeText={setName}
        style={styles.input}
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        style={styles.input}
      />
      <TextInput
        placeholder="Пароль"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      <Button title="Зареєструватися" onPress={handleRegister} />
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center', 
    marginBottom: 20,
    lineHeight: 40, 
  },
  bodyText: {
  fontSize: 16,
  textAlign: 'center', 
  marginBottom: 10,
  color: '#333', 
  },
  input: {
  width: '100%',
  height: 40,
  borderColor: '#ccc',
  borderWidth: 1,
  borderRadius: 5,
  marginBottom: 15,
  paddingLeft: 10,
  backgroundColor: "#dcc4db",
  },
});