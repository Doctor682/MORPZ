import React from 'react';
import { View, Text, StyleSheet, FlatList, Image, ScrollView } from 'react-native';
import { useSelector } from 'react-redux';

const Forum = ({ navigation }) => {
  const posts = useSelector(state => state.user.posts); // Забираємо пости зі стейту Redux

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Форум</Text>
      <ScrollView style={styles.scrollContainer}>
        <FlatList
          data={posts}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <View style={styles.post}>
              <Text style={styles.postText} numberOfLines={3} ellipsizeMode="tail">
                {item.text}
              </Text>
              {item.photo && (
                <Image
                  source={{ uri: item.photo }} // Використовуємо посилання на фото
                  style={styles.postImage}
                />
              )}
            </View>
          )}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#e3f2fd', // Світло-блакитний фон
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
    color: '#0d47a1', // Темно-синій текст заголовка
  },
  scrollContainer: {
    flex: 1,
  },
  post: {
    backgroundColor: '#ffffff', // Білий фон для поста
    padding: 8,
    marginBottom: 10,
    borderRadius: 10, // Заокруглені кути
    borderWidth: 1,
    borderColor: '#90caf9', // Блакитна межа
    shadowColor: '#000', // Тінь для ефекту підняття
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    maxHeight: 180, // Обмежуємо висоту поста
    overflow: 'hidden', // Запобігає виходу контенту за межі
  },
  postText: {
    fontSize: 20,
    color: '#1a237e', // Темно-синій колір тексту
    marginBottom: 5,
  },
  postImage: {
    width: '100%',
    height: 120, // Обмежуємо висоту фото
    resizeMode: 'cover',
    borderRadius: 6, // Заокруглені кути зображення
  },
});

export default Forum;
